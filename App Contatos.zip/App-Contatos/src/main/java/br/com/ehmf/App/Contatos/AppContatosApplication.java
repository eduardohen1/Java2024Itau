package br.com.ehmf.App.Contatos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppContatosApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppContatosApplication.class, args);
	}

}
