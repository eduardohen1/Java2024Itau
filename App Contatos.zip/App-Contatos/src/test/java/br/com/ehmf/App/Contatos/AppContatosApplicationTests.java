package br.com.ehmf.App.Contatos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppContatosApplicationTests {

	@Test
	void contextLoads() {
	}

}
